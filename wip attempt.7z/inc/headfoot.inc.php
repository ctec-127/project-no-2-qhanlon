<?php 
    $header = "<header>
    <h1>Welcome to Project 2</h1>
</header>";
    $footer = "<footer>
    <h2>This has been Project 2</h2>
</footer>";

?>